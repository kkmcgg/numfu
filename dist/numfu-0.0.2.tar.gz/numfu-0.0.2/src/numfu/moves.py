import numpy

def identity_stance(arr):
    print('IDENTITY STANCE')
    print(arr.shape)
    return arr