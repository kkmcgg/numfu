![image](numfu.png)


# The Prophecy

There is a champion. He is scattered through time. He has been and will always be. He knows numfu. 

# Numfu

Numfu is python. Numfy is numpy. It is from time. It is our heart. It flows. Numfu. 

# The Cadinal Ether

There are two. There is zero and there is one. They flow though the numfu master. 
He understands that Zero is not one and one is not Zero.

# Metacongruencey

The numfu master can slice without reshaping. He can make all changes and yet remain in place.  
He flows though without water. 

# Visons

The numfu master can see the beauty. He is calm. The answer is for him waiting. Numfu sees him.

# The tester

Those who do must be undone.

# The seer 

The seer sees.

# Numfu Moves

# Seek Greatness

import numpy as np

g = np.zeros((100,50))

xa = g.shape[-1]

g[34,25] = 1

v = np.argmax(g)
print(v)

y = int(v/xa)
print(y)

x = v - (xa*y)
print(x)

# Good things

- fung shui (num shui?)

- fancy keyboards

- black and white things

- RGB

- midi

- plants

- reptiles

- water

- keytars 

- space

# pretty good things

- tires 

- umbrellas 

- smoke machines 

- gears 

- pumps

![image](https://user-images.githubusercontent.com/36888812/116952337-ceb8fd80-ac60-11eb-86e9-68c08dba2087.png)

#names
https://en.wikipedia.org/wiki/Greek_letters_used_in_mathematics,_science,_and_engineering

#setup guide
https://medium.com/@joel.barmettler/how-to-upload-your-python-package-to-pypi-65edc5fe9c56
